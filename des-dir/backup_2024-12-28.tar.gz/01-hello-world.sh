#!/bin/bash

echo "hello ,iam learning devops"

echo "hello, iam practing devops"