#!/bin/bash

echo "Step 1: This will execute"
nonexistent_command  # This command does not exist and will fail
echo "Step 2: This will still execute"
