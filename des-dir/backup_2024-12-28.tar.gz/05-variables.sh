#!/bin/bash

echo -n "please enter user name :: " 
read  USERNAME 

echo -n "please enter password :: "  
read -s PASSWORD

echo "USERNAME is : $USERNAME"
echo "PASSWORD is : $PASSWORD"

