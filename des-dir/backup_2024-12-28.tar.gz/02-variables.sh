#!/bin/bash

echo "Ramesh :: Hello Suresh, How are you?"
echo "Suresh :: Hi Ramesh, Iam fine, How are you ?"
echo "Ramesh :: Iam fine too... How is your work?"
echo "Suresh :: Not bad. Iam thinking to upgrade to Devops"


