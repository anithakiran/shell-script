#!/bin/bash

No1=$1
No2=$2

SUM=$(($No1+$No2))
SUB=$(($No1-$No2))

echo "Total of $No1 and $No2 is : $SUM"
echo "Half of $No1 and $No2 is : $SUB"