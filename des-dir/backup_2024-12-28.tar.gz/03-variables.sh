#!/bin/bash

PERSON1=RAMESH
PERSON2=SURESH

echo "$PERSON1 :: Hello $PERSON2, How are you?"
echo "$PERSON2 :: Hi $PERSON1, Iam fine, How are you ?"
echo "$PERSON1 :: Iam fine too... How is your work?"
echo "$PERSON2 :: Not bad. Iam thinking to upgrade to Devops"


