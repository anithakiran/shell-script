#!/bin/bash

COURSE="DevOps from Other Script"

echo "Variable value from Other script: $COURSE"
echo "Process ID of other script: $$"