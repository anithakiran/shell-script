#!/bin/bash

WEEKS=("SUNDAY" "MONDAY" "TUESDAY" "WEDNESDAY" "THURSDAY" "FRIDAY" "SATURDAY")


echo "First day of the week is : ${WEEKS[0]}"
echo "Third day of the week is : ${WEEKS[3]}" 
echo "Days of the week :${WEEKS[@]}"
echo "last day of the week is : ${WEEKS[6]}"
