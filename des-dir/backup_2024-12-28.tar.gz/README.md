# shell-script
shell practice
